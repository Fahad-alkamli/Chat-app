package alkamli.fahad.chat.chat.model;


import java.util.ArrayList;
public class ArrayList2 <E> extends ArrayList<E> {




    public E getLast()
    {

        return this.get(this.size()-1);
    }

}
